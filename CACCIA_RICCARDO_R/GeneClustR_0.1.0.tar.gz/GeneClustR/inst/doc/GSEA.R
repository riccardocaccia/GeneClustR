## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, warning = FALSE, message = FALSE)
library(GeneClustR)
library(clusterProfiler)
library(org.Hs.eg.db)
library(limma)
library(ggplot2)

## -----------------------------------------------------------------------------
set.seed(123)

# Let's simulate expression data for 100 genes and 10 samples
genes <- paste0("ENSG", sprintf("%011d", 1:100))
samples <- paste0("Sample", 1:10)
mat <- matrix(rnorm(1000), nrow = 100, dimnames = list(genes, samples))

# preprocessing
mat <- preprocess(mat, normalize = TRUE, method = "log")

# groups labels
groups <- rep(c("A", "B"), each = 5)

## -----------------------------------------------------------------------------
gsea_res_no <- gsea_analysis(mat, keyType = "ENSEMBL", condition = "no")
gsea_res_no$plot


## -----------------------------------------------------------------------------
gsea_res_cond <- gsea_analysis(mat, keyType = "ENSEMBL", condition = "yes", groups = groups)

if (!is.null(gsea_res_cond$plot)) {
  gsea_res_cond$plot
} else {
  cat("No significantly enriched GO term found.")
}


## -----------------------------------------------------------------------------
# Firsts lines result visualization
head(gsea_res_cond$gsea@result)


